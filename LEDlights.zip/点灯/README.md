# STM32-LED — GPIO 点灯例程

基于 **STM32F103C8T6** + **STM32F10x 标准外设库（SPL）** 的 GPIO 输出实验：让 PA0、PA3、PA6 三个 LED 依次闪烁，每个状态保持 500 ms。

开发环境：Keil MDK（工程文件 `project.uvprojx`）。

## 功能

`main()` 中把 GPIOA 配置为 **推挽输出、50 MHz**，然后在死循环里依次翻转三个引脚：

| 顺序 | 引脚 | 动作 | 延时 |
|---|---|---|---|
| 1 | PA0 | 输出低（点亮） | 500 ms |
| 2 | PA0 | 输出高（熄灭） | 500 ms |
| 3 | PA3 | 输出低 | 500 ms |
| 4 | PA3 | 输出高 | 500 ms |
| 5 | PA6 | 输出低 | 500 ms |
| 6 | PA6 | 输出高 | 500 ms |

关键代码（`user/main.c`）：

```c
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);   // 使能 GPIOA 时钟

GPIO_InitTypeDef GPIO_InitStructure;
GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;        // 推挽输出
GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_All;
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_Init(GPIOA, &GPIO_InitStructure);

while (1)
{
    GPIO_ResetBits(GPIOA, GPIO_Pin_0);   // PA0 输出低电平
    Delay_ms(500);
    GPIO_SetBits(GPIOA, GPIO_Pin_0);     // PA0 输出高电平
    Delay_ms(500);
    /* PA3、PA6 同理 */
}
```

## 硬件连接

LED 采用**灌电流**接法（引脚输出低电平点亮）：

```
PA0 ──[ 限流电阻 470Ω~1kΩ ]──|◀── GND
PA3 ──[ 限流电阻 470Ω~1kΩ ]──|◀── GND
PA6 ──[ 限流电阻 470Ω~1kΩ ]──|◀── GND
```

## 延时实现

`system/Delay.c` 使用 **SysTick** 做忙等待延时，不占用定时器外设：

- `Delay_us(x)`：`SysTick->LOAD = 72 * x`，即按 **72 MHz** HCLK 计算，范围 0 ~ 233015 us
- `Delay_ms(x)` / `Delay_s(x)`：在 `Delay_us` 基础上循环

> ⚠️ 若系统主频不是 72 MHz，`Delay_us()` 中的 72 需要改成对应的主频值（MHz），否则延时不准确。

## 目录结构

```
├── project.uvprojx      Keil MDK 工程文件
├── user/                应用代码
│   ├── main.c           主程序（GPIO 初始化 + 闪烁循环）
│   ├── stm32f10x_it.c   中断服务函数
│   ├── stm32f10x_it.h
│   └── stm32f10x_conf.h 标准库配置（裁剪用到的外设）
├── system/              自定义驱动
│   ├── Delay.c          SysTick 微秒/毫秒/秒级延时
│   └── Delay.h
├── start/               启动与 CMSIS
│   ├── startup_stm32f10x_md.s
│   ├── system_stm32f10x.c
│   ├── stm32f10x.h
│   └── core_cm3.c / core_cm3.h
└── library/             STM32F10x 标准外设库（SPL）
```

## 编译与下载

1. 用 Keil uVision5 打开 `project.uvprojx`（需要已安装 STM32F1 器件支持包和 ARM Compiler 5）。
2. 编译（F7）后通过 ST-Link / J-Link 下载到 STM32F103C8T6 最小系统板。
3. 若目标芯片不同，在 `Options for Target` 里改器件型号，并确认 `start/` 中使用的启动文件与容量匹配（本工程用 `startup_stm32f10x_md.s`，即中容量）。
