#include "stm32f10x.h"                  // Device header
#include "Delay.h"

int main(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_IintStructure;
	GPIO_IintStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_IintStructure.GPIO_Pin = GPIO_Pin_All;
	GPIO_IintStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_IintStructure);
	while(1)
	{	
		GPIO_ResetBits(GPIOA, GPIO_Pin_0);
		Delay_ms(500);
		GPIO_SetBits(GPIOA, GPIO_Pin_0);
		Delay_ms(500);
		GPIO_ResetBits(GPIOA, GPIO_Pin_3);
		Delay_ms(500);
		GPIO_SetBits(GPIOA, GPIO_Pin_3);
		Delay_ms(500);
		GPIO_ResetBits(GPIOA, GPIO_Pin_6);
		Delay_ms(500);
		GPIO_SetBits(GPIOA, GPIO_Pin_6);
		Delay_ms(500);
	}
}
